﻿// Задача 2
// int a = 7;
// int b = 5;
// int max = a;
// int min = b;
// if (b > a) max = b; min = a;
// if (a > b) max = a; min = b;
// if (a == b) max = min = a = b;

// Console.Write(max);

// Задача 4
// int a = 2;
// int b = 8;
// int c = 7;
// int max = a;

// if (b > max) max = b;
// if (c > max) max = c;

// Console.Write(max);

// Задача 6
// Console.WriteLine("Введите число:");
// int number = Convert.ToInt32(Console.ReadLine());
// if (number % 2 == 0) {Console.Write("Это чётное число");}
// else {Console.Write("Это нечётное число");}

// Задача 8
// Console.WriteLine("Введите число:");
// int N = Convert.ToInt32(Console.ReadLine());

// for (int i = 1; i <= N; i++)
//     if (i % 2 == 0) {Console.Write(i + " ");}